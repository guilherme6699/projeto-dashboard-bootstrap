function Enviar(){
   alert("Relatorio Enviado");
}

function relatar(){
   alert("seu Relato foi Enviado para Nossa equipe de tecnicos, logo sera Notificado da Resolução do seu poblema ");
   history.back();
}